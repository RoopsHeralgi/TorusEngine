package torusEngine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

//import com.google.common.collect.Table.Cell;

import io.github.bonigarcia.wdm.WebDriverManager;

public class torusengine 
{
	private static final String Feature_folder_path = "src/test/resources/featureFiles";
	String sampleFeature=readFeatureFile(Feature_folder_path);

	public torusengine() throws InterruptedException 
	{
		System.out.println(sampleFeature);
		WebDriver driver = null;
		String[] features = sampleFeature.split("\n");

		for (String feature : features) 
	 {
		 switch(getAction(feature).toLowerCase()) 
		 {
		 	case "launch":
		 	driver = launchBrowser();
		 	break;

		 	case "enters":
		 	if (getTarget(feature).equalsIgnoreCase("url")) 
		 	{
		 		driver.get(getData(feature));
		 	}
		 	else 
		 	{
		 		try 
		 		{
		 			driver.findElement(By.id(getTarget(feature))).sendKeys(getData(feature));
		 		}
		 		catch(Exception e)
		 		{
		 			driver.findElement(By.name(getTarget(feature))).sendKeys(getData(feature));
		 			Thread.sleep(15000);
 
		 		}
		 		try 
		 		{
		 			Thread.sleep(4000);
		 			driver.findElement(By.cssSelector(getTarget(feature))).sendKeys(getData(feature));
		 		}
		 		catch(Exception e)
		 		{
		 			//driver.findElement(By.xpath(getTarget(feature))).sendKeys(getData(feature));
		 		}
		 	}
		 	break;
		 	case "click":
	        try {	
	        		driver.findElement(By.id(getTarget(feature))).click();
	        		Thread.sleep(3000);
	            } catch (Exception e) 
	        	{
					captureScreenshot(driver, "Error in clicking: " + e.getMessage());
				}
	        break;
		 }
		 try 
		 {
			 Thread.sleep(5000);
		 } 
		 catch (InterruptedException e) 
		 {
			 e.printStackTrace();
		 }
		
		 
	 }
	}
	
 	private String readFeatureFile(String featureFolderPath) {
		StringBuilder content = new StringBuilder();
		
		try {
			File folder = new File(featureFolderPath);
			File[] files = folder.listFiles();
			
			if(files!= null) 
			{
				for(File file:files) 
				{
					if(file.isFile())
					{
						BufferedReader reader = new BufferedReader(new FileReader(file));
						String line;
						while((line = reader.readLine())!= null)
						{
							content.append(line);
							content.append("\n"); //Add a new line after each line read
							if(line.matches(".*YourPattern.*")) 
							{
								System.out.println("Match found:"+line);
							}
						}
						reader.close();
					}
					
				}
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		return content.toString();
	}
	
	    private String getAction(String feature) {
        Pattern pattern = Pattern.compile("<(.*?)>");
        Matcher matcher = pattern.matcher(feature);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

     private String getData(String feature) {
        Pattern pattern = Pattern.compile("\\[(.*?)\\]");
        Matcher matcher = pattern.matcher(feature);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }

    private String getTarget(String feature) {
        Pattern pattern = Pattern.compile("\\{(.*?)\\}");
        Matcher matcher = pattern.matcher(feature);
        if (matcher.find()) {
            return matcher.group(1);
        }
        return "";
    }
    
    private String getTargetDateMatcher(String feature) {
    	String dobInput = "12-04-1990";
    	Pattern pattern = Pattern.compile("\\[(\\d{2}-\\d{2}-\\d{4})\\]");
    	Matcher matcher = pattern.matcher(dobInput);
    	if (matcher.find())
    	{
    		String day = matcher.group(1);
    		String month = matcher.group(2);
    		String year = matcher.group(3);
    	}
    	return null;
    	}
    
    private void captureScreenshot(WebDriver driver, String fileName) {
    	
    	Date currentdate = new Date();
    	String screenshotfilename = currentdate.toString().replace(" ", "-").replace(":","-");
    	System.out.println(screenshotfilename);
        try {
            File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            FileUtils.copyFile(screenshotFile, new File(".//screenshot/" + screenshotfilename +".png"));
            System.out.println("Screenshot captured: " + fileName);
        } catch (WebDriverException | IOException e) {
            System.out.println("Failed to capture screenshot: " + e.getMessage());
        }
    }

    public WebDriver launchBrowser() {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        return new ChromeDriver(options);
    }
	public static void main(String[] args) throws InterruptedException 
	{
		new torusengine();

	}
}




